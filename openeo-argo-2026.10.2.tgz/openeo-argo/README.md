## OpenEO Argoworkflows Helm Chart

This chart deploys an OpenEO Api and OpenEO Processes deployment which gets executed on Argo Workflows. 

The deployment is intended to be a consumer of a STAC catalogue. The data provided by STAC should be available over http/s, so that it can be remotely consumed by the pods responsible for processing.

OpenEO Process Graphs that are provided, get parsed into an Argo Workflow which runs the executor. The executor is responsible for the deserialisation of the process graph, and will execute the corresponding process, if existing on the backend. The output of the processing is written to the job workspace.

Currently, persistent storage is handled via a persistent volume claim ( PVC ) which is known to both the api, and executor pods. Currently, dask gateway is not installed, but this PVC will additionally need to be mounted there in the future. It is not the responsibility of the helm chart to manage backing up the PVC that is used for the persistent storage of OpenEO jobs.


## Installation

Installation with microk8s into the kubernetes cluster. If not using microk8s, just remove the microk8s command.

### Microk8s
```
microk8s kubectl create ns test

microk8s helm dependency build

microk8s helm upgrade --install openeo -n test -f values.yaml .
```

## Parameters

### Deployment values

| Key                | Description                                           | Value |
|--------------------|-------------------------------------------------------|-------|
| global.env.alembicDir         | Directory for Alembic migrations.          |   "/opt/openeo_argoworkflows_api/psql    |
| global.env.apiDns             | API DNS address. If localhost, include port.                                       |   127.0.0.1:8000    |
| global.env.apiTLS             | API TLS configuration (true/false)                    |   False    |
| global.env.apiTitle           | Title of the API                                      |   "OpenEO ArgoWorkflows"    |
| global.env.apiDescription     | Description of the API                                |   "A K8S deployment of the openeo api for argoworkflows."    |
| global.env.oidcUrl            | URL for OpenID Connect authentication                 |   "https://aai.egi.eu/auth/realms/egi"    |
| global.env.oidcOrganisation   | Organisation for OpenID Connect authentication        |  "egi"   |
| global.env.oidcPolicies       | Policies for OpenID Connect authorization             |    ""  |
| global.env.oidcProviderTitle  | Display title of the OIDC provider                    |  "EGI Check-in"  |
| global.env.oidcClientId       | Client ID registered with the OIDC provider           |  "openeo-platform-default-client"  |
| global.env.oidcCustomerClaim  | Userinfo claim (dot-separated path) holding the customer, used as the value of the `meteringCustomerLabel` label with `@` written as `_at_`. |  ""  |
| global.env.meteringCustomerLabel | Label key carrying the customer on job workflows and dask pods, e.g. `eodc.eu/customer`. Requires oidcCustomerClaim; users without that claim cannot start jobs. Empty omits the label. |  ""  |
| global.env.meteringProjectLabel | Label key carrying `meteringProject` on job workflows and dask pods, e.g. `eodc.eu/project`. Empty omits the label. |  ""  |
| global.env.meteringProject    | Value of the `meteringProjectLabel` label. Required when meteringProjectLabel is set. |  ""  |
| global.env.stacCatalogueUrl   | URL for a single STAC catalogue. Always set, and required by the API even when stacCatalogueUrls is used  |   "https://stac.eodc.eu/api/v1"    |
| global.env.stacCatalogueUrls  | URLs of the STAC catalogues to proxy. Their collections are combined, deduplicated by id keeping the first match, and then filtered by stacCollectionsWhitelist. Takes precedence over stacCatalogueUrl  |   []    |
| global.env.stacCollectionsWhitelist | STAC collection ids served by the API. Empty serves all. Ignored when whitelistConfigMap is set. |   []    |
| global.env.processWhitelist   | openEO process ids offered by the API and executor. Empty offers all. Ignored when whitelistConfigMap is set. |   []    |
| global.env.whitelistConfigMap | Name of an existing ConfigMap providing the whitelists as comma-separated ids under the keys `STAC_COLLECTIONS_WHITELIST` and `OPENEO_PROCESS_WHITELIST`, both required. The chart does not create it, and pods must be restarted to pick up changes. |   ""    |
| global.env.workspaceRoot      | Root directory for user workspaces                    |   "/user_workspaces/jobs"    |
| global.env.workspaceMount      | The mount path for the volume where the user workspaces are stored  |   "/user_workspaces"    |
| global.env.executorImage      | Image for the executor                                |   "ghcr.io/eodcgmbh/openeo-argoworkflows:executor-2026.3.4"    |
| global.env.daskWorkerCores      | Cores available to the dask worker                               |   "4"    |
| global.env.daskWorkerMemoryGiB      | RAM available to the dask worker, in GiB (2**30 bytes)                              |   "8"    |
| global.env.daskWorkerLimit      | Maximum number of workers available per job.                              |   "6"    |
| global.env.daskClusterTimeout      | How long an idle cluster can be left unused.                              |   "3600"    |
| global.env.netcdfLocalWriteBytes      | Output size (bytes) at or above which the executor serialises the netCDF write instead of using the dask cluster, forwarded to the executor. Empty leaves it disabled. |   ""    |
| global.env.jobRetentionDays      | Jobs created more than this many days ago are deleted with their results by the queue worker. Empty or 0 keeps jobs forever. |   ""    |
| global.env.awsDefaultRegion      | AWS region for the Icechunk store, forwarded to the executor.                              |   "us-east-1"    |
| global.env.awsEndpointUrl      | AWS S3 endpoint URL for the Icechunk store, forwarded to the executor.                              |   ""    |
| global.env.eodagDedlPriority      | EODAG DEDL provider priority, forwarded to the executor.                              |   "10"    |
| global.env.icechunkS3ConnectTimeoutMs      | Icechunk S3 connect timeout (ms), forwarded to the executor.                              |   "15000"    |
| global.env.icechunkS3OperationAttemptTimeoutMs      | Icechunk S3 per-attempt operation timeout (ms), forwarded to the executor.                              |   "30000"    |
| global.env.icechunkS3OperationTimeoutMs      | Icechunk S3 overall operation timeout (ms), forwarded to the executor.                              |   "120000"    |
| global.env.executorSecret.name      | Name of an existing secret holding the sensitive executor credentials (AWS keys, EODAG login). Empty disables it; the chart references but does not create this secret.                              |   ""    |
| global.env.executorSecret.awsAccessKeyIdKey      | Key in `executorSecret` holding `AWS_ACCESS_KEY_ID`.                              |   "aws-access-key-id"    |
| global.env.executorSecret.awsSecretAccessKeyKey      | Key in `executorSecret` holding `AWS_SECRET_ACCESS_KEY`.                              |   "aws-secret-access-key"    |
| global.env.executorSecret.eodagUsernameKey      | Key in `executorSecret` holding the EODAG DEDL username.                              |   "eodag-username"    |
| global.env.executorSecret.eodagPasswordKey      | Key in `executorSecret` holding the EODAG DEDL password.                              |   "eodag-password"    |
| image.repository      | Image for the OpenEO Api                                |   "ghcr.io/eodcgmbh/openeo-argoworkflows"    |
| image.tag      | Tag for the OpenEO Api                              | "api-2026.3.11"  |
| persistence.existingVolume      | existingVolume is a map used to define configurable values in the deployment. If not set, a pvc will be created by the chart.  | "" |
| persistence.existingVolume.enabled      | Whether the existingVolume map should be used. | false  |
| persistence.existingVolume.name      | The name of an existing Persistent Volume Claim to be used for the OpenEO Workspace. If used, both persistence.storageClassName and persistence.capacity will be ignored. | ""  |
| persistence.fsGroup      |   The fsGroup to be used for the security context for the existing volume.  | 1000 |
| persistence.storageClassName      |   The storage class to be used when creating the persistent volume. | "microk8s-hostpath" |
| persistence.capacity      |   The size of the Persistent Volume Claim to be used for the OpenEO Workspace        | "8Gi"  |

#### Example: global.env.oidcPolicies

Setting the oidcPolicies is explained [here](https://eodcgmbh.github.io/openeo-fastapi/package/client/settings/) in the OpenEO FastApi documentation. The list is provided via the helm chart as a single string. The default value in the chart is an empty string, this disables the policy check and allows any valid token from the issuer.


### Dependency values

These dependencies are required for the OpenEO Deployment. In theory existing deployments for each of dependencies could be used if they already exist, the helm chart has just not yet been configured to support this. For now, leave these values as is.

It is possible to configure the additional helm values for these charts.

| Key                | Description                                           | Value |
|--------------------|-------------------------------------------------------|-------|
|  postgresql.enabled     |   Whether to install postgresql within the OpenEO Deployment                            | True |
|  argoworkflows.enabled     |   Whether to install argoworkflows within the OpenEO Deployment     | True |
|  redis.enabled     |   Whether to install redis within the OpenEO Deployment   | True |

#### ! Notice !

The images used in this chart for redis and postgresql now must use the bitnamilegacy repository as a consequence of bitnami removing their publicly
available docker images. The default values have been updated to now parse the bitnamilegacy docker repo.

## Dependencies

**Argo Worfklows**

Argo Workflows is used for initializing the executor on the k8s cluster in order to consume the provided OpenEO process graph.

Helm Chart: https://github.com/argoproj/argo-helm/tree/main/charts/argo-workflows


**PostgreSQL**

PostgreSQL is used for keeping track of the OpenEO users that have accessed the backend, the user defined process graphs that they have created, and the jobs they have created and submitted to argo. The persistence for psql is handled independently from the persistent storage used for the physical OpenEO job results.

Helm Chart: https://github.com/bitnami/charts/tree/main/bitnami/postgresql


**Redis**

Redis is used in ordered to queue and limit the number of jobs that are submitted to Argo Workflows at any given time. Additionally, tasks are added to the queue to poll Argo Workflows untill the workflow is finished.

Helm Chart: https://github.com/bitnami/charts/tree/main/bitnami/redis


## Outstanding work

- Tiling the outputs of save result.

- Update helm chart to allow for disabling the installation of chart dependencies and reusing existing deployments.
